var searchData=
[
  ['base_5fobject',['base_object',['../classbase__object.html',1,'base_object'],['../classbase__object.html#a6c3928ac6aaf6b645c18ea8b7717dbd6',1,'base_object::base_object()'],['../classbase__object.html#aae443eac7c3fe83ea76ce4006359aaa7',1,'base_object::base_object(int)']]],
  ['bullet',['bullet',['../_my_form_8cpp.html#aa64fd95f94ea26c2529831656d5de9b4',1,'MyForm.cpp']]]
];
