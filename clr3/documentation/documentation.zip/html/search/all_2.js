var searchData=
[
  ['disactive',['disactive',['../classbase__object.html#a87c6fdcdcca46c1839d0bf7fae110574',1,'base_object']]],
  ['down',['down',['../classplayer.html#a7bc7d32663c11671b181a120844e0efc',1,'player']]]
];
