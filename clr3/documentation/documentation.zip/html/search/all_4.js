var searchData=
[
  ['game_5fengine_2ecpp',['game_engine.cpp',['../game__engine_8cpp.html',1,'']]],
  ['game_5fengine_2eh',['game_engine.h',['../game__engine_8h.html',1,'']]],
  ['get_5fsize_5fx',['get_size_x',['../classbase__object.html#a9b018abfe21170353c163cad9511f02c',1,'base_object']]],
  ['get_5fsize_5fy',['get_size_y',['../classbase__object.html#a58391e1cc3093e8b6ee1aaeadd8335d5',1,'base_object']]],
  ['get_5fx',['get_x',['../classbase__object.html#a53e9ce3dd05e9de706e05a5ec9df8d1e',1,'base_object']]],
  ['get_5fy',['get_y',['../classbase__object.html#ad1ff677f0809e24496f87c27ea2c65ec',1,'base_object']]]
];
