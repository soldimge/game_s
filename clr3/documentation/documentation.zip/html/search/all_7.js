var searchData=
[
  ['object',['object',['../classobject.html',1,'object'],['../classobject.html#a04aad740887b47c735b9ed9078e45d77',1,'object::object()']]]
];
