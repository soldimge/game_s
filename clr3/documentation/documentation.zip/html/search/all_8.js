var searchData=
[
  ['player',['player',['../classplayer.html',1,'player'],['../classplayer.html#ab1d9c2ebef05e45ed3c25561d8704111',1,'player::player()']]],
  ['present',['present',['../classpresent.html',1,'present'],['../classpresent.html#a06bf3a0b515b081093a6c3fdc10de80e',1,'present::present()']]],
  ['present_5fbox',['present_box',['../_my_form_8cpp.html#a348101dce229fb2d3b8c417ac8c5fc43',1,'MyForm.cpp']]]
];
