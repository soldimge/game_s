var searchData=
[
  ['white_5fblock',['white_block',['../_my_form_8cpp.html#aa027617cc3769db0f2bd27eaaf6a4819',1,'MyForm.cpp']]]
];
