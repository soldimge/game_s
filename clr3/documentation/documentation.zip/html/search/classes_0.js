var searchData=
[
  ['base_5fobject',['base_object',['../classbase__object.html',1,'']]]
];
