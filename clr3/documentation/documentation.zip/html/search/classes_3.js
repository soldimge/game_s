var searchData=
[
  ['player',['player',['../classplayer.html',1,'']]],
  ['present',['present',['../classpresent.html',1,'']]]
];
