var searchData=
[
  ['player',['player',['../classplayer.html#ab1d9c2ebef05e45ed3c25561d8704111',1,'player']]],
  ['present',['present',['../classpresent.html#a06bf3a0b515b081093a6c3fdc10de80e',1,'present']]]
];
