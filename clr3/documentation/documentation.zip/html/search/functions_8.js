var searchData=
[
  ['renew',['renew',['../classobject.html#a2fe455d0f7b85018d2984888cbef18b8',1,'object::renew()'],['../classpresent.html#a991ff8f7047cd6ab6e04b0935e9fba8c',1,'present::renew()']]],
  ['right',['right',['../classplayer.html#ae2b3482d0e525c9f58caa01431836f7e',1,'player']]]
];
