var searchData=
[
  ['set_5fbasic_5fspeed',['set_basic_speed',['../classobject.html#a8a93112d56c32430e1eb5560d2db6912',1,'object']]],
  ['set_5fspeed',['set_speed',['../classbase__object.html#a6aa28faa9734744b5992da58121e6095',1,'base_object']]]
];
