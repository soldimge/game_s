var searchData=
[
  ['up',['up',['../classplayer.html#a3b29bfd1cef8c8934fa0c5ffc93fd539',1,'player']]]
];
