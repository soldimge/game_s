var indexSectionsWithContent =
{
  0: "bcdeglmoprstuw~",
  1: "bmop",
  2: "gm",
  3: "bcdglmoprstu~",
  4: "beprstuw",
  5: "ct"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "related"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Классы",
  2: "Файлы",
  3: "Функции",
  4: "Переменные",
  5: "Друзья"
};

